namespace DigitalLibrary;

public interface IMultimedia
{
    void Reproducir();
    void MostrarDemo();
}